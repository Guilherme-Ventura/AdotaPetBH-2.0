import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-sign-up',
  templateUrl: './modal-sign-up.component.html',
  styleUrls: ['./modal-sign-up.component.css']
})
export class ModalSignUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
