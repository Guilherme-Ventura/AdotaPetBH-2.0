import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adopt',
  templateUrl: './adopt.component.html',
  styleUrls: ['./adopt.component.css']
})
export class AdoptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
